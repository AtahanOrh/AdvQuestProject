package proje;

import javax.swing.*;
import java.awt.*;

public class GameUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private JComboBox<String> characterBox;
    private JButton startButton;
    private final String username; // encapsulation

    public GameUI(String username) {
        this.username = username;

        // pencere ayarları
        setTitle("Select Your Character");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // üst panel
        JPanel topPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        topPanel.add(new JLabel("Character:"));
        String[] characters = {"Samurai", "Archer", "Knight"};
        characterBox = new JComboBox<>(characters);
        topPanel.add(characterBox);

        startButton = new JButton("Start Game");
        topPanel.add(new JLabel());
        topPanel.add(startButton);

        add(topPanel, BorderLayout.CENTER);

        // oyunu başlatmayı tetikleyen kısım
        startButton.addActionListener(e -> startGame());

        setVisible(true);
    }

    // seçilen karaktere göre oyunu başlatır
    private void startGame() {
        String selectedChar = (String) characterBox.getSelectedItem();

        Player player = new Player(username);

        // seçilen karaktere göre istatistikler ayarlanır
        switch (selectedChar) {
            case "Samurai" -> player.initPlayer("Samurai", 35, 150, 0);
            case "Archer"  -> player.initPlayer("Archer", 55, 120, 0);
            case "Knight"  -> player.initPlayer("Knight", 25, 180, 0);
        }

        // oyuncu bilgisini veri tabanına kaydeder
        DatabaseHelper.savePlayerData(player);

        // asıl oyunu başlatır
        new GameWindow(player);
        dispose(); // karakter seçme arayüzü kapanır
    }
}
