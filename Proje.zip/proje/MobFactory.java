package proje;

public class MobFactory {
	
	public static Mob create(String name) {
	    return switch (name) {
	        case "Zombie" -> new Zombie();
	        case "Vampire" -> new Vampire();
	        case "Bear" -> new Bear();
	        case "Ghost" -> new Ghost(); // 👈 Bunu ekle
	        default -> new Zombie(); // 

	    };
	}

}
