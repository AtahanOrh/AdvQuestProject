package proje;

import java.util.*;

public class Inventory {
    private boolean water, firewood, food;
    private String wName, aName;
    private int damage, armor;

    private final List<String> weapons = new ArrayList<>();
    private final List<String> armors = new ArrayList<>();
    private String selectedWeapon;
    private String selectedArmor;

    private final Map<String, Integer> weaponDamages = new HashMap<>();
    private final Map<String, Integer> armorValues = new HashMap<>();

    public Inventory() {
        this.water = false;
        this.firewood = false;
        this.food = false;
        this.damage = 0;
        this.armor = 0;
        this.wName = null;
        this.aName = null;
    }

    // ------------------ Görev Ödülleri ------------------
    public boolean isWater() { return water; }
    public void setWater(boolean water) { this.water = water; }

    public boolean isFirewood() { return firewood; }
    public void setFirewood(boolean firewood) { this.firewood = firewood; }

    public boolean isFood() { return food; }
    public void setFood(boolean food) { this.food = food; }

    // ------------------ Stat Getter/Setter ------------------
    public String getwName() { return wName; }
    public void setwName(String wName) { this.wName = wName; }

    public String getaName() { return aName; }
    public void setaName(String aName) { this.aName = aName; }

    public int getDamage() { return damage; }
    public void setDamage(int damage) { this.damage = damage; }

    public int getArmor() { return armor; }
    public void setArmor(int armor) { this.armor = armor; }

    // ------------------ Overloaded Envantere Ekleme ------------------

    // Otomatik kuşanır
    public void addWeapon(String name, int damage) {
        addWeapon(name, damage, true);
    }

    // Overloaded: Kuşanma kontrolü
    public void addWeapon(String name, int damage, boolean autoEquip) {
        if (!weapons.contains(name)) {
            weapons.add(name);
            weaponDamages.put(name, damage);
        }
        if (autoEquip) {
            selectedWeapon = name;
            setDamage(damage);
            setwName(name);
        }
    }

    // Otomatik kuşanır
    public void addArmor(String name, int armor) {
        addArmor(name, armor, true);
    }

    // Overloaded: Kuşanma kontrolü
    public void addArmor(String name, int armor, boolean autoEquip) {
        if (!armors.contains(name)) {
            armors.add(name);
            armorValues.put(name, armor);
        }
        if (autoEquip) {
            selectedArmor = name;
            setArmor(armor);
            setaName(name);
        }
    }

    // ------------------ Liste Getter ------------------
    public List<String> getWeapons() { return weapons; }
    public List<String> getArmors() { return armors; }

    // ------------------ Kuşanma ------------------
    public void equipWeapon(String name) {
        if (weapons.contains(name)) {
            selectedWeapon = name;
            setwName(name);
            setDamage(weaponDamages.get(name));
        }
    }

    public void equipArmor(String name) {
        if (armors.contains(name)) {
            selectedArmor = name;
            setaName(name);
            setArmor(armorValues.get(name));
        }
    }

    // ------------------ Kuşanmayı Bırak ------------------
    public void unequipWeapon() {
        selectedWeapon = null;
        setwName(null);
        setDamage(0);
    }

    public void unequipArmor() {
        selectedArmor = null;
        setaName(null);
        setArmor(0);
    }

    // ------------------ Seçili Öğeler ------------------
    public String getSelectedWeapon() { return selectedWeapon; }
    public void setSelectedWeapon(String selectedWeapon) { this.selectedWeapon = selectedWeapon; }

    public String getSelectedArmor() { return selectedArmor; }
    public void setSelectedArmor(String selectedArmor) { this.selectedArmor = selectedArmor; }
}
