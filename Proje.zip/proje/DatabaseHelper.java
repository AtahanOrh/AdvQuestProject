package proje;

import java.sql.*;

public class DatabaseHelper {
    // veri tabanı yolunu tanımlar
    private static final String DB_URL = "jdbc:sqlite:" + System.getProperty("user.dir") + "/adventure_game.db";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    // eğer yoksa, veri tabanı tablolarını oluşturur
    public static void initializeDatabase() {
        createUserTableIfNotExists();
        createPlayersTableIfNotExists();
    }

    // kullanıcı bilgilerin kaydeden veri tabanı tablosunu oluşturur
    public static void createUserTableIfNotExists() {
        String sql = """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            );
        """;

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("User table error: " + e.getMessage());
        }
    }

    // oyuncunun tüm bilgilerini tutan veri tabanı tablosunu oluşturur
    public static void createPlayersTableIfNotExists() {
        String sql = """
            CREATE TABLE IF NOT EXISTS players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                character TEXT,
                money INTEGER,
                weapons TEXT,
                armors TEXT,
                items TEXT,
                finished INTEGER DEFAULT 0
            );
        """;

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Players table error: " + e.getMessage());
        }
    }

    // giriş bilgilerini kontrol eder
    public static boolean validateLogin(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username.toLowerCase());
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    // yeni kayıt oluşturur
    public static boolean registerUser(String username, String password) {
        String sql = "INSERT INTO users(username, password) VALUES(?, ?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username.toLowerCase());
            pstmt.setString(2, password);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    // oyuncu bilgilerini kaydeder/günceller
    public static void savePlayerData(Player player) {
        String sql = """
            INSERT INTO players(username, character, money, weapons, armors, items, finished)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(username) DO UPDATE SET
                character = excluded.character,
                money = excluded.money,
                weapons = excluded.weapons,
                armors = excluded.armors,
                items = excluded.items,
                finished = excluded.finished;
        """;

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, player.getName().toLowerCase());
            pstmt.setString(2, player.getCharName());
            pstmt.setInt(3, player.getMoney());

            // envanter verilerini kaydeder
            String weapons = String.join(",", player.getInv().getWeapons());
            String armors = String.join(",", player.getInv().getArmors());

            // görev eşyası verilerini kaydeder
            StringBuilder items = new StringBuilder();
            if (player.getInv().isFood()) items.append("Food,");
            if (player.getInv().isFirewood()) items.append("Firewood,");
            if (player.getInv().isWater()) items.append("Water,");

            pstmt.setString(4, weapons);
            pstmt.setString(5, armors);
            pstmt.setString(6, items.toString());

            pstmt.setInt(7, player.isGameFinished() ? 1 : 0);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("❌ Failed to save player data: " + e.getMessage());
        }
    }

    // veri tabanında bulunan bilgileri yükler
    public static Player loadPlayerData(String username) {
        String sql = "SELECT * FROM players WHERE username = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username.toLowerCase());
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Player player = new Player(username.toLowerCase());
                String charName = rs.getString("character");

                // seçilen karakterin istatistiklerini ayarlar
                switch (charName) {
                    case "Samurai" -> player.initPlayer("Samurai", 35, 150, 0);
                    case "Archer"  -> player.initPlayer("Archer", 55, 120, 0);
                    case "Knight"  -> player.initPlayer("Knight", 25, 180, 0);
                }

                player.setCharName(charName);
                player.setMoney(rs.getInt("money"));

                Inventory inv = player.getInv();

                // silahların istatistiklerini ayarlar
                String[] weaponArr = rs.getString("weapons").split(",");
                for (String w : weaponArr) {
                    if (!w.isBlank()) {
                        int dmg = switch (w) {
                            case "Dagger" -> 15;
                            case "Longsword"  -> 50;
                            case "Ghost Slayer"  -> 80;
                            default       -> 0;
                        };
                        inv.addWeapon(w, dmg, false);
                    }
                }

                // zırhların istatistiklerini ayarlar
                String[] armorArr = rs.getString("armors").split(",");
                for (String a : armorArr) {
                    if (!a.isBlank()) {
                        int val = switch (a) {
                            case "Light Armor"  -> 10;
                            case "Medium Armor" -> 50;
                            case "Heavy Armor"  -> 75;
                            default             -> 0;
                        };
                        inv.addArmor(a, val, false);
                    }
                }

                // varsa görev eşyalarını yükler
                String items = rs.getString("items");
                if (items.contains("Food")) inv.setFood(true);
                if (items.contains("Firewood")) inv.setFirewood(true);
                if (items.contains("Water")) inv.setWater(true);

                // ekipmanı otomatik kuşanır
                if (!inv.getWeapons().isEmpty()) inv.equipWeapon(inv.getWeapons().get(0));
                if (!inv.getArmors().isEmpty()) inv.equipArmor(inv.getArmors().get(0));

                // oyunun bitirilip bitirilmediğini kontrol eder
                player.setGameFinished(rs.getInt("finished") == 1);

                return player;
            }
        } catch (SQLException e) {
            System.out.println("❌ Load error: " + e.getMessage());
        }
        return null;
    }
}
