package proje;

import javax.swing.*;
import java.awt.*;

public class ShopWindow extends JFrame {
    private static final long serialVersionUID = 1L;
    private Player player;
    private GameWindow gameWindow;

    public ShopWindow(Player player, GameWindow gameWindow) {
        this.player = player;
        this.gameWindow = gameWindow;

        setTitle("Shop");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(0, 1));

        // Silahlar
        addWeaponButton(buttonPanel, outputArea, "Dagger", 15, 15);
        addWeaponButton(buttonPanel, outputArea, "Longsword", 50, 150);
        addWeaponButton(buttonPanel, outputArea, "Ghost Slayer", 80, 900);

        // Zırhlar
        addArmorButton(buttonPanel, outputArea, "Light Armor", 10, 20);
        addArmorButton(buttonPanel, outputArea, "Medium Armor", 50, 200);
        addArmorButton(buttonPanel, outputArea, "Heavy Armor", 75, 950);

        add(buttonPanel, BorderLayout.NORTH);
        setVisible(true);
    }

    private void addWeaponButton(JPanel panel, JTextArea output, String name, int dmg, int price) {
        JButton btn = new JButton(name + " (+" + dmg + " dmg) - " + price + " gold");

        // oyuncuda varsa baştan devre dışı yap
        if (player.getInv().getWeapons().contains(name)) {
            btn.setEnabled(false);
        }

        btn.addActionListener(e -> {
            try {
                if (player.getInv().getWeapons().contains(name)) {
                    output.append("⚠️ You already own " + name + "\n");
                    return;
                }

                if (player.getMoney() < price) {
                    throw new InsufficientFundsException("Not enough money!");
                }

                player.setMoney(player.getMoney() - price);
                player.getInv().addWeapon(name, dmg, true); // Overloaded method
                output.append("✅ Bought and equipped: " + name + "\n");
                btn.setEnabled(false);
                gameWindow.updateStats();
            } catch (InsufficientFundsException ex) {
                output.append("❌ " + ex.getMessage() + "\n");
            }
        });

        panel.add(btn);
    }


    private void addArmorButton(JPanel panel, JTextArea output, String name, int armor, int price) {
        JButton btn = new JButton(name + " (+" + armor + " armor) - " + price + " gold");

        if (player.getInv().getArmors().contains(name)) {
            btn.setEnabled(false);
        }

        btn.addActionListener(e -> {
            try {
                if (player.getInv().getArmors().contains(name)) {
                    output.append("⚠️ You already own " + name + "\n");
                    return;
                }

                if (player.getMoney() < price) {
                    throw new InsufficientFundsException("Not enough money!");
                }

                player.setMoney(player.getMoney() - price);
                player.getInv().addArmor(name, armor, true); // Overloaded method
                output.append("✅ Bought and equipped: " + name + "\n");
                btn.setEnabled(false);
                gameWindow.updateStats();
            } catch (InsufficientFundsException ex) {
                output.append("❌ " + ex.getMessage() + "\n");
            }
        });

        panel.add(btn);
    }


}
