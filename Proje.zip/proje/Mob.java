package proje;

import java.util.Random;

public abstract class Mob {
    private static final Random r = new Random();

    private String name;
    private int damage, loot, health, max;

    public Mob(String name, int damage, int health, int loot, int max) {
        this.name = name;
        this.damage = damage;
        this.loot = loot;
        this.health = health;
        this.max = max;
    }

    public int count() {
        return r.nextInt(this.max) + 1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getLoot() {
        return loot;
    }

    public void setLoot(int loot) {
        this.loot = loot;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    @Override
    public String toString() {
        return name + " (DMG: " + damage + ", HP: " + health + ", Loot: " + loot + ")";
    }
}
