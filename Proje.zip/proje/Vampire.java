package proje;

public class Vampire extends Mob{

	public Vampire() {
		super("Vampire", 30, 170, 100, 3);
	}

}

