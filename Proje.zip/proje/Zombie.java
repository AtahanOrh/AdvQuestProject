package proje;

public class Zombie extends Mob{

	public Zombie() {
		super("Zombie", 25, 100, 10, 3); //(damage, health, money, count)
	}

}