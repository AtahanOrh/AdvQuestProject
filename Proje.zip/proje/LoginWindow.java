package proje;

import javax.swing.*;
import java.awt.*;

public class LoginWindow extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginWindow() {
        setTitle("Login - Adventure Game");
        setSize(350, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 10, 15));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        loginBtn.addActionListener(e -> login());
        registerBtn.addActionListener(e -> register());

        panel.add(loginBtn);
        panel.add(registerBtn);

        add(panel, BorderLayout.CENTER);
        setVisible(true);

        DatabaseHelper.initializeDatabase();
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (DatabaseHelper.validateLogin(username, password)) {
            JOptionPane.showMessageDialog(this, "Login successful!");

            Player player = DatabaseHelper.loadPlayerData(username);

            if (player != null && player.isGameFinished()) {
                // Oyun bitmişse victory ekranından başlat
                new GameWindow(player, true);
            } else if (player != null) {
                new GameWindow(player);
            } else {
                new GameUI(username); // İlk kez giriyorsa karakter seçtir
            }

            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void register() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        // Username regex kontrolü
        if (!username.matches("^[a-zA-Z0-9]{3,15}$")) {
            JOptionPane.showMessageDialog(this, "Username must be 3-15 characters long and contain only letters and numbers.", "Invalid Username", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Password regex kontrolü
        if (!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}$")) {
            JOptionPane.showMessageDialog(this, "Password must be at least 6 characters long and include a number, a lowercase and an uppercase letter.", "Invalid Password", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (DatabaseHelper.registerUser(username, password)) {
            JOptionPane.showMessageDialog(this, "Registration successful. You can now log in.");
        } else {
            JOptionPane.showMessageDialog(this, "Username already taken!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
