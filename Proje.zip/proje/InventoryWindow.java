package proje;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class InventoryWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    private final Player player;
    private final GameWindow gameWindow;
    private JTextArea outputArea;
    private final Map<String, JButton> weaponButtons = new HashMap<>();
    private final Map<String, JButton> armorButtons = new HashMap<>();
    private JPanel rewardPanel;

    public GameWindow getGameWindow() {
        return gameWindow;
    }

    public InventoryWindow(Player player, GameWindow gameWindow) {
        this.player = player;
        this.gameWindow = gameWindow;

        setTitle("Inventory");
        setSize(600, 450); // Genişlik sabit, yükseklik biraz artırıldı
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // ---------- ORTA PANEL: Silah ve Zırh ----------
        JPanel centerPanel = new JPanel(new GridLayout(1, 2)); // Sadece silah ve zırh için
        add(centerPanel, BorderLayout.CENTER);

        // ---------- Silahlar ----------
        JPanel weaponPanel = new JPanel(new GridLayout(0, 1));
        weaponPanel.setBorder(BorderFactory.createTitledBorder("Weapons"));

        List<String> weapons = player.getInv().getWeapons();
        for (String weapon : weapons) {
            JButton btn = new JButton(weapon);
            if (weapon.equals(player.getInv().getSelectedWeapon())) {
                btn.setBackground(Color.ORANGE);
            }

            btn.addActionListener(e -> {
                player.getInv().equipWeapon(weapon);
                outputArea.append("✅ Equipped weapon: " + weapon + "\n");
                updateButtonColors();
            });

            weaponButtons.put(weapon, btn);
            weaponPanel.add(btn);
        }

        JButton unequipWeapon = new JButton("Unequip Weapon");
        unequipWeapon.addActionListener(e -> {
            player.getInv().unequipWeapon();
            outputArea.append("⚠️ Weapon unequipped.\n");
            updateButtonColors();
        });
        weaponPanel.add(unequipWeapon);
        centerPanel.add(weaponPanel);

        // ---------- Zırhlar ----------
        JPanel armorPanel = new JPanel(new GridLayout(0, 1));
        armorPanel.setBorder(BorderFactory.createTitledBorder("Armors"));

        List<String> armors = player.getInv().getArmors();
        for (String armor : armors) {
            JButton btn = new JButton(armor);
            if (armor.equals(player.getInv().getSelectedArmor())) {
                btn.setBackground(Color.ORANGE);
            }

            btn.addActionListener(e -> {
                player.getInv().equipArmor(armor);
                outputArea.append("✅ Equipped armor: " + armor + "\n");
                updateButtonColors();
            });

            armorButtons.put(armor, btn);
            armorPanel.add(btn);
        }

        JButton unequipArmor = new JButton("Unequip Armor");
        unequipArmor.addActionListener(e -> {
            player.getInv().unequipArmor();
            outputArea.append("⚠️ Armor unequipped.\n");
            updateButtonColors();
        });
        armorPanel.add(unequipArmor);
        centerPanel.add(armorPanel);

        // ---------- ALT PANEL ----------
        JPanel bottomPanel = new JPanel(new BorderLayout());
        add(bottomPanel, BorderLayout.SOUTH);

        // Görev Ödülleri (alt tarafta)
        rewardPanel = new JPanel(new GridLayout(1, 3));
        rewardPanel.setBorder(BorderFactory.createTitledBorder("Quest Rewards"));
        updateRewardDisplay(); // Ödülleri göster
        bottomPanel.add(rewardPanel, BorderLayout.NORTH);

        // Çıkış butonu
        JButton closeButton = new JButton("Close Inventory");
        closeButton.addActionListener(e -> {
            if (gameWindow != null) {
                gameWindow.updateStats();
            }
            dispose();
        });
        bottomPanel.add(closeButton, BorderLayout.SOUTH);

        // ---------- ALTTA MESAJ ALANI ----------
        outputArea = new JTextArea(4, 20);
        outputArea.setEditable(false);
        bottomPanel.add(new JScrollPane(outputArea), BorderLayout.CENTER);

        setVisible(true);
    }

    private void updateButtonColors() {
        String selectedWeapon = player.getInv().getSelectedWeapon();
        String selectedArmor = player.getInv().getSelectedArmor();

        for (String w : weaponButtons.keySet()) {
            JButton btn = weaponButtons.get(w);
            btn.setBackground(w.equals(selectedWeapon) ? Color.ORANGE : null);
        }

        for (String a : armorButtons.keySet()) {
            JButton btn = armorButtons.get(a);
            btn.setBackground(a.equals(selectedArmor) ? Color.ORANGE : null);
        }
    }

    private void updateRewardDisplay() {
        rewardPanel.removeAll();

        rewardPanel.add(new JLabel("Food: " + (player.getInv().isFood() ? "✓" : "✗")));
        rewardPanel.add(new JLabel("Firewood: " + (player.getInv().isFirewood() ? "✓" : "✗")));
        rewardPanel.add(new JLabel("Water: " + (player.getInv().isWater() ? "✓" : "✗")));

        rewardPanel.revalidate();
        rewardPanel.repaint();
    }
}
