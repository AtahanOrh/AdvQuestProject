package proje;

public class Bear extends Mob{

	public Bear() {
		super("Bear", 80, 300, 450, 2); //(damage, health, money, count)
	}

}