package proje;

public class Ghost extends Mob {
	
    public Ghost() {
        super("Ghost", 100, 500, 3000, 1); // Tek düşman, yüksek hasar ve can
    }
    
}
