package proje;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.HashMap;

public class GameWindow extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextArea outputArea;
    private JLabel hpLabel, moneyLabel, weaponLabel, damageLabel, armorLabel;
    private Player player;
    private JPanel battlePanel;
    private JButton hitButton, fleeButton;
    private String currentEnemy;
    private int enemyHP, enemyDamage;
    private boolean inBattle = false;
    private int totalEnemies = 0;
    private int currentEnemyIndex = 0;
    private Mob enemyMob;
    private String locationReward;
    private Map<String, JButton> locationButtonMap = new HashMap<>();
    private ShopWindow shopWindow;

    public GameWindow(Player player, boolean startWithVictoryScreen) {
        this(player);
        if (startWithVictoryScreen) {
            showVictoryScreen(); // oyun önceden bitirilmişse direkt zafer ekranını getirir
        }
    }

    // asıl oyun penceresini oluşturur
    public GameWindow(Player player) {
        this.player = player;

        setTitle("Adventure Game - Main");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // üst panel, genel oyuncu bilgileri ve butonlar
        JPanel infoPanel = new JPanel(new GridLayout(2, 4));
        hpLabel = new JLabel();
        damageLabel = new JLabel();
        moneyLabel = new JLabel();
        weaponLabel = new JLabel();
        armorLabel = new JLabel();

        infoPanel.add(hpLabel);
        infoPanel.add(damageLabel);
        infoPanel.add(moneyLabel);
        infoPanel.add(weaponLabel);
        infoPanel.add(armorLabel);

        JButton inventoryButton = new JButton("Inventory");
        inventoryButton.addActionListener(e -> new InventoryWindow(player, this));
        infoPanel.add(inventoryButton);

        JButton saveExitButton = new JButton("Save & Exit");
        saveExitButton.addActionListener(e -> {
            DatabaseHelper.savePlayerData(player); // veri tabanına kaydeder
            JOptionPane.showMessageDialog(this, "Game saved successfully!");
            System.exit(0); // oyunu kapatır
        });
        infoPanel.add(saveExitButton);

        add(infoPanel, BorderLayout.NORTH);

        // orta panel, oyunda olanların yazdığı metin bölmesi
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        // alt panel, lokasyonlar arası geçiş
        JPanel locationPanel = new JPanel(new GridLayout(1, 6));
        String[] locations = {"Base", "Cave", "Forest", "River", "Castle", "Weaponary"};

        for (String loc : locations) {
            JButton btn = new JButton(loc);
            btn.addActionListener(e -> handleLocation(loc)); // her butonu lokasyonuyla eşler
            locationPanel.add(btn);
            locationButtonMap.put(loc, btn);
        }

        locationButtonMap.get("Castle").setEnabled(false); // castle'a önceden girilememesini sağlar
        add(locationPanel, BorderLayout.SOUTH);

        // sağ panel, savaş mekanikleri
        battlePanel = new JPanel();
        hitButton = new JButton("Hit");
        fleeButton = new JButton("Flee");

        hitButton.addActionListener(e -> {
            if (inBattle) playerTurn();
        });

        fleeButton.addActionListener(e -> {
            if (inBattle) {
                outputArea.append("You fled from the battle.\n");
                endBattle(false);
            }
        });

        battlePanel.add(hitButton);
        battlePanel.add(fleeButton);
        battlePanel.setVisible(false);
        add(battlePanel, BorderLayout.EAST);

        updateStats();
        setVisible(true);
    }

    // lokasyon seçimi
    private void handleLocation(String locName) {
        outputArea.append("\n>> You selected: " + locName + "\n");

        switch (locName) {
            case "Base" -> {
                player.setHealth(player.getrHealth()); // canı doldurur
                outputArea.append("You are healed to full HP.\n");
            }
            case "Weaponary" -> {
                outputArea.append("You enter the shop...\n");
                if (shopWindow == null || !shopWindow.isDisplayable()) {
                    shopWindow = new ShopWindow(player, this); // yeni bir pencere açar
                } else {
                    shopWindow.toFront(); // açılan pencereyi öne getirir
                }
            }
            case "Cave", "Forest", "River" -> {
                // lokasyona göre düşman ve ödül belirler
                currentEnemy = switch (locName) {
                    case "Cave" -> "Zombie";
                    case "Forest" -> "Vampire";
                    case "River" -> "Bear";
                    default -> "???";
                };

                locationReward = Map.of(
                        "Cave", "Food",
                        "Forest", "Firewood",
                        "River", "Water"
                ).get(locName);

                int choice = JOptionPane.showConfirmDialog(this,
                        "A wild " + currentEnemy + " appears!\nDo you want to fight?",
                        "Battle!",
                        JOptionPane.YES_NO_OPTION);

                if (choice == JOptionPane.YES_OPTION) {
                    startBattle(currentEnemy);
                } else {
                    outputArea.append("You ran away safely.\n");
                }
            }
            case "Castle" -> {
                Inventory inv = player.getInv();
                if (inv.isFood() && inv.isFirewood() && inv.isWater()) {
                    currentEnemy = "Ghost";
                    locationReward = null;

                    int choice = JOptionPane.showConfirmDialog(this,
                            "\uD83D\uDC7B The Ghost King awaits in the Castle!\nDo you wish to enter the final battle?",
                            "Final Boss - Castle",
                            JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION) {
                        startBattle(currentEnemy);
                    } else {
                        outputArea.append("You left the Castle safely.\n");
                    }
                } else {
                    outputArea.append("❌ You need all quest items (Food, Firewood, Water) to enter the Castle!\n");
                }
            }
        }

        updateStats();
    }

    // savaşı başlatır
    private void startBattle(String enemyName) {
        this.enemyMob = MobFactory.create(enemyName); // polymorphism: mob tipi üretildi
        this.totalEnemies = enemyMob.count();
        this.currentEnemyIndex = 1;
        this.enemyHP = enemyMob.getHealth();
        this.enemyDamage = enemyMob.getDamage();
        this.inBattle = true;

        outputArea.append("\u2694\uFE0F Battle started! You will fight " + totalEnemies + " " + enemyName + "(s).\n");

        hitButton.setEnabled(true);
        fleeButton.setEnabled(true);
        battlePanel.setVisible(true);
        setLocationButtonsEnabled(false); // savaşta lokasyon seçimini devre dışı bırakır
        showStats();
    }

    // oyuncu saldırırsa gerçekleşecek animasyonları ve bekleme süresini ayarlar
    private void playerTurn() {
        hitButton.setEnabled(false);
        fleeButton.setEnabled(false);

        // multithreading: arka planda dövüş animasyonu çalıştırılır
        SwingWorker<Void, String> battleWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                publish("🗡️ You attack...");
                Thread.sleep(750);
                enemyHP -= player.getTotalDamage();
                publish("Enemy " + currentEnemyIndex + " HP: " + Math.max(0, enemyHP));
                Thread.sleep(750);

                if (enemyHP <= 0) {
                    publish("💥 Enemy " + currentEnemyIndex + " defeated!");
                    player.setMoney(player.getMoney() + enemyMob.getLoot());
                    currentEnemyIndex++;

                    if (currentEnemyIndex > totalEnemies) {
                        publish("🎉 You cleared all enemies in this location!");
                        Thread.sleep(750);
                        return null;
                    } else {
                        enemyHP = enemyMob.getHealth();
                        publish("⚔️ New enemy approaching! Enemy " + currentEnemyIndex + " of " + totalEnemies);
                        Thread.sleep(750);
                        return null;
                    }
                }

                // düşman saldırısı
                publish("👹 Enemy attacks...");
                Thread.sleep(750);
                int taken = Math.max(0, enemyDamage - player.getInv().getArmor());
                player.setHealth(player.getHealth() - taken);
                publish("You took " + taken + " damage! Your HP: " + player.getHealth());
                Thread.sleep(0);

                return null;
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                for (String msg : chunks) {
                    outputArea.append(msg + "\n");
                }
                updateStats();
            }

            @Override
            protected void done() {
                if (player.getHealth() <= 0) {
                    outputArea.append("💀 You died. Game Over.\n");
                    JOptionPane.showMessageDialog(GameWindow.this, "You are dead. Game over.");
                    System.exit(0);
                }

                if (currentEnemyIndex > totalEnemies) {
                    endBattle(true);
                } else {
                    hitButton.setEnabled(true);
                    fleeButton.setEnabled(true);
                }
            }
        };

        battleWorker.execute();
    }

    // savaş sonucuna göre ilerlemeyi ayarlar
    private void endBattle(boolean won) {
        hitButton.setEnabled(false);
        fleeButton.setEnabled(false);
        battlePanel.setVisible(false);
        inBattle = false;
        setLocationButtonsEnabled(true);

        boolean unlockedSomething = false;

        if (won && locationReward != null) {
            Inventory inv = player.getInv();
            switch (locationReward) {
                case "Food" -> {
                    if (!inv.isFood()) {
                        inv.setFood(true);
                        outputArea.append("🎁 You obtained: Food!\n");
                        unlockedSomething = true;
                    }
                }
                case "Firewood" -> {
                    if (!inv.isFirewood()) {
                        inv.setFirewood(true);
                        outputArea.append("🎁 You obtained: Firewood!\n");
                        unlockedSomething = true;
                    }
                }
                case "Water" -> {
                    if (!inv.isWater()) {
                        inv.setWater(true);
                        outputArea.append("🎁 You obtained: Water!\n");
                        unlockedSomething = true;
                    }
                }
            }
        }

        // bütün itemleri aldıktan sonra kalenin kilidi açılır
        if (unlockedSomething) {
            Inventory inv = player.getInv();
            if (inv.isFood() && inv.isFirewood() && inv.isWater()) {
                JButton castleBtn = locationButtonMap.get("Castle");
                if (castleBtn != null && !castleBtn.isEnabled()) {
                    castleBtn.setEnabled(true);
                    outputArea.append("🏰 The path to the Castle has opened!\n");
                }
            }
        }

        // finall boss yenildiyse zafer ekranı gelir
        if (won && "Ghost".equals(currentEnemy)) {
            player.setGameFinished(true);
            DatabaseHelper.savePlayerData(player);
            showVictoryScreen();
            return;
        }

        updateStats();
    }

    // oyuncu ve düşman istatistiklerini gösterir
    private void showStats() {
        outputArea.append("\n🧙 Your Stats:\n");
        outputArea.append("HP: " + player.getHealth() + "\n");
        outputArea.append("Damage: " + player.getTotalDamage() + "\n");
        outputArea.append("Armor: " + player.getInv().getArmor() + "\n");

        outputArea.append("\n👹 Enemy (" + currentEnemy + ") Stats:\n");
        outputArea.append("HP: " + enemyHP + "\n");
        outputArea.append("Damage: " + enemyDamage + "\n");
    }

    // üst paneldeki istatistikleri günceller
    public void updateStats() {
        hpLabel.setText("HP: " + player.getHealth());
        moneyLabel.setText("Money: " + player.getMoney());
        weaponLabel.setText("Weapon: " + (player.getInv().getwName() != null ? player.getInv().getwName() : "None"));
        damageLabel.setText("Damage: " + player.getTotalDamage());
        armorLabel.setText("Armor: " + player.getInv().getArmor());

        Inventory inv = player.getInv();
        if (inv.isFood() && inv.isFirewood() && inv.isWater()) {
            JButton castleBtn = locationButtonMap.get("Castle");
            if (castleBtn != null && !castleBtn.isEnabled()) {
                castleBtn.setEnabled(true);
                outputArea.append("🏰 The path to the Castle has opened!\n");
            }
        }
    }

    private void setLocationButtonsEnabled(boolean enabled) {
        for (Map.Entry<String, JButton> entry : locationButtonMap.entrySet()) {
            if (!entry.getKey().equals("Castle")) {
                entry.getValue().setEnabled(enabled);
            }
        }
    }

    // zafer ekranını ayarlar
    private void showVictoryScreen() {
        setLocationButtonsEnabled(false);
        hitButton.setEnabled(false);
        fleeButton.setEnabled(false);

        String message = """
                👑 You have defeated the Ghost King!
                🏆 The land is safe once again...

                Would you like to play again?
                """;

        int choice = JOptionPane.showOptionDialog(
                this,
                message,
                "Victory!",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{"Play Again", "Exit"},
                "Play Again"
        );

        if (choice == JOptionPane.YES_OPTION) {
            this.dispose();
            new GameUI(player.getName()); // yeni oyun seçeneği
        } else {
            System.exit(0); // oyunu kapatma seçeneği
        }
    }
}
